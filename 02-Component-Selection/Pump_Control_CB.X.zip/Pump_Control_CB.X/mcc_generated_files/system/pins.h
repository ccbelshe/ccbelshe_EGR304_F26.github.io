/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA2 aliases
#define MOTOR_CNTRL_TRIS                 TRISAbits.TRISA2
#define MOTOR_CNTRL_LAT                  LATAbits.LATA2
#define MOTOR_CNTRL_PORT                 PORTAbits.RA2
#define MOTOR_CNTRL_WPU                  WPUAbits.WPUA2
#define MOTOR_CNTRL_OD                   ODCONAbits.ODCA2
#define MOTOR_CNTRL_ANS                  ANSELAbits.ANSELA2
#define MOTOR_CNTRL_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define MOTOR_CNTRL_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define MOTOR_CNTRL_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define MOTOR_CNTRL_GetValue()           PORTAbits.RA2
#define MOTOR_CNTRL_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define MOTOR_CNTRL_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define MOTOR_CNTRL_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define MOTOR_CNTRL_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define MOTOR_CNTRL_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define MOTOR_CNTRL_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define MOTOR_CNTRL_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define MOTOR_CNTRL_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RC2 aliases
#define PUMP_CMD1_TRIS                 TRISCbits.TRISC2
#define PUMP_CMD1_LAT                  LATCbits.LATC2
#define PUMP_CMD1_PORT                 PORTCbits.RC2
#define PUMP_CMD1_WPU                  WPUCbits.WPUC2
#define PUMP_CMD1_OD                   ODCONCbits.ODCC2
#define PUMP_CMD1_ANS                  ANSELCbits.ANSELC2
#define PUMP_CMD1_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define PUMP_CMD1_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define PUMP_CMD1_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define PUMP_CMD1_GetValue()           PORTCbits.RC2
#define PUMP_CMD1_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define PUMP_CMD1_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define PUMP_CMD1_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define PUMP_CMD1_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define PUMP_CMD1_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define PUMP_CMD1_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define PUMP_CMD1_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define PUMP_CMD1_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define PUMP_CMD0_TRIS                 TRISCbits.TRISC3
#define PUMP_CMD0_LAT                  LATCbits.LATC3
#define PUMP_CMD0_PORT                 PORTCbits.RC3
#define PUMP_CMD0_WPU                  WPUCbits.WPUC3
#define PUMP_CMD0_OD                   ODCONCbits.ODCC3
#define PUMP_CMD0_ANS                  ANSELCbits.ANSELC3
#define PUMP_CMD0_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define PUMP_CMD0_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define PUMP_CMD0_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define PUMP_CMD0_GetValue()           PORTCbits.RC3
#define PUMP_CMD0_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define PUMP_CMD0_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define PUMP_CMD0_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define PUMP_CMD0_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define PUMP_CMD0_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define PUMP_CMD0_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define PUMP_CMD0_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define PUMP_CMD0_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RD0 aliases
#define DEBUG_LED_TRIS                 TRISDbits.TRISD0
#define DEBUG_LED_LAT                  LATDbits.LATD0
#define DEBUG_LED_PORT                 PORTDbits.RD0
#define DEBUG_LED_WPU                  WPUDbits.WPUD0
#define DEBUG_LED_OD                   ODCONDbits.ODCD0
#define DEBUG_LED_ANS                  ANSELDbits.ANSELD0
#define DEBUG_LED_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define DEBUG_LED_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define DEBUG_LED_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define DEBUG_LED_GetValue()           PORTDbits.RD0
#define DEBUG_LED_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define DEBUG_LED_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define DEBUG_LED_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define DEBUG_LED_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define DEBUG_LED_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define DEBUG_LED_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define DEBUG_LED_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define DEBUG_LED_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define DEBUG_BTN_TRIS                 TRISDbits.TRISD1
#define DEBUG_BTN_LAT                  LATDbits.LATD1
#define DEBUG_BTN_PORT                 PORTDbits.RD1
#define DEBUG_BTN_WPU                  WPUDbits.WPUD1
#define DEBUG_BTN_OD                   ODCONDbits.ODCD1
#define DEBUG_BTN_ANS                  ANSELDbits.ANSELD1
#define DEBUG_BTN_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define DEBUG_BTN_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define DEBUG_BTN_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define DEBUG_BTN_GetValue()           PORTDbits.RD1
#define DEBUG_BTN_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define DEBUG_BTN_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define DEBUG_BTN_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define DEBUG_BTN_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define DEBUG_BTN_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define DEBUG_BTN_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define DEBUG_BTN_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define DEBUG_BTN_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/